"""Build the standalone website into ./site: index.html + data/*.js + live.js, plus the repo scaffolding
(GitHub Actions daily refresh, README, requirements).   python -m breakout.site [--default-team BB|'']

The site is static: it runs anywhere that serves files (GitHub Pages, Netlify, Cloudflare Pages, a folder on your PC).
Live pieces (posted probables, lineups, scores, first-pitch weather) are fetched in the browser straight from MLB and
Open-Meteo, which both allow cross-origin requests; the models and ownership tables come from the daily build.
"""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path
from . import config as C
from .assemble import HD_COLS, PS_COLS, G_COLS, columnar

ROOT = Path(__file__).resolve().parents[1]

WORKFLOW = r'''name: refresh
on:
  schedule:
    - cron: "0 10 * * *"      # every day 10:00 UTC (6 am Eastern) — new probables, rosters, forecasts
  workflow_dispatch:
    inputs:
      full:
        description: "Rebuild the season models too (slow, ~25 min)"
        default: "false"
permissions:
  contents: write
concurrency: refresh
jobs:
  refresh:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.11", cache: "pip" }
      - run: pip install -r requirements.txt
      - name: Full model rebuild (manual only)
        if: ${{ github.event.inputs.full == 'true' }}
        run: python -m breakout.pipeline3
      - name: This week's streamers (schedule, probables, rosters, weather, splits)
        run: python -m breakout.pipeline_streamers
      - name: Assemble the site
        run: |
          python -m breakout.build_v4
          python -m breakout.assemble
          python -m breakout.site --default-team ""
      - name: Commit
        run: |
          git config user.name "lab-bot"
          git config user.email "lab-bot@users.noreply.github.com"
          git add -A site output data/availability data/injuries
          git commit -m "refresh $(date -u +%F)" || echo "nothing to commit"
          git push
'''

README = r'''# Philly Special Lab

A fantasy-baseball site for a 12-team Fantrax H2H points keeper league. Everything is scored in the league's own points.

**What is on the site:** dashboard (your lineup by day, parks and weather, pickups, keeper board, breakout watch),
hitter and starting-pitcher labs with Statcast, Stuff+/Location+/Pitching+ proxies, career-relative Breakout Indexes,
a Streamers tab (matchups, park factors, first-pitch weather, two-start pitchers, the 10-start cap), keeper boards and
draft pools, the league's real drafts, TJStats-style prospect cards, and a Methods page.

**Live in the browser** (no server): posted probable pitchers, game states and scores, today's lineups once they are
posted, and first-pitch weather — refreshed every 10 minutes from the MLB Stats API and Open-Meteo. Click the LIVE dot
to refresh now.

**Daily build (GitHub Actions, 6 am ET):** re-runs the streamer pipeline (rotations, rosters, IL, splits, park factors,
forecasts) and republishes the site. "Run workflow" with `full = true` rebuilds the season models (projections,
Breakout Index, keeper values, prospect cards) — do that after the season or whenever you want the models refreshed.

## Put it online (GitHub Pages, free)

1. Create a GitHub account if you do not have one, then a new repository (public is fine; the data is public data).
2. Upload this whole folder (drag and drop on the repo page works: "Add file → Upload files"), or `git push` it.
3. Repository **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main, folder: /site**. Save.
4. Your site is at `https://<your-username>.github.io/<repo-name>/` within a minute or two. Share that link.
5. **Settings → Actions → General → Workflow permissions → Read and write** so the daily refresh can commit.
   The refresh runs on its own every morning; the Actions tab shows each run.

Fantrax ownership (who owns whom) cannot be pulled by the daily job because it needs your Fantrax login; it is refreshed
from the CSVs in `data/fantrax/` whenever you update them (ask Claude to re-export them from your Chrome session, or
export the Players page yourself).

## Run it locally

```
pip install -r requirements.txt
python -m breakout.pipeline_streamers      # this week's matchups (5–8 minutes; talks to MLB, Savant, Open-Meteo)
python -m breakout.build_v4 && python -m breakout.assemble && python -m breakout.site
open site/index.html
```

`python -m breakout.pipeline3` rebuilds the season models (25 minutes with a warm cache).
'''

REQS = "pandas>=2.2\nnumpy>=1.26\nrequests>=2.31\nscikit-learn>=1.4\npyarrow>=15\nscipy>=1.11\n"
GITIGNORE = """__pycache__/
*.pyc
.DS_Store
# raw caches the pipelines re-download when missing (keeps the repo small)
data/milb_statcast/
data/mlb/
data/savant/
data/milb/
data/injuries/transactions_*.json
# generated pages (the site/ folder is the one that is served)
output/*/philly_special*.html
"""


def build(default_team: str):
    site = ROOT / "site"; (site / "data").mkdir(parents=True, exist_ok=True)
    tpl = (C.OUT / "v4" / "explorer_template.html").read_text(encoding="utf-8")
    data = json.loads((C.OUT / "v3" / "explorer_data.json").read_text())
    cfg = json.loads((C.DATA / "fantrax" / "league_config.json").read_text()); data["meta"]["team_names"] = cfg.get("fantasy_team_abbrevs", {})
    data["meta"]["default_team"] = default_team
    s = json.loads((C.OUT / "streamers" / "streamers.json").read_text())
    stream = dict(meta=s["meta"], hitter_days=columnar(s["hitter_days"], HD_COLS), pitcher_starts=columnar(s["pitcher_starts"], PS_COLS), games=columnar(s["games"], G_COLS),
                  park_factors=s["park_factors"], venues=s.get("venues", []))
    (site / "data" / "lab.js").write_text("window.__LAB__=" + json.dumps(data, separators=(",", ":")) + ";", encoding="utf-8")
    (site / "data" / "streamers.js").write_text("window.__STREAM__=" + json.dumps(stream, separators=(",", ":")) + ";", encoding="utf-8")
    # site index: data comes from the two script files; live layer after boot
    html = tpl.replace('<script id="data" type="application/json">__DATA__</script>', '<script src="data/lab.js"></script>\n<script src="data/streamers.js"></script>')
    html = html.replace("const D = JSON.parse(document.getElementById('data').textContent);", "const D = window.__LAB__; D.streamers = window.__STREAM__;")
    html = html.replace("<title>Philly Special Hitter Lab</title>", "<title>Philly Special Lab</title>")
    page = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
            "<meta name=\"description\" content=\"Philly Special fantasy baseball lab: lineups, streamers, keepers, breakouts and prospect cards in the league's points.\">\n"
            "<link rel=\"icon\" href=\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cpath d='M4 4h24v12L16 30 4 16z' fill='%23E5484D'/%3E%3Cpath d='M8 8h16v7l-8 10-8-10z' fill='%23fff' opacity='.92'/%3E%3C/svg%3E\">\n"
            "<style>body{margin:0;color-scheme:dark light}img{max-width:100%}[hidden]{display:none!important}</style>\n</head>\n<body>\n" + html + "\n<script src=\"live.js\"></script>\n</body>\n</html>\n")
    (site / "index.html").write_text(page, encoding="utf-8")
    shutil.copy(Path(__file__).with_name("site_live.js"), site / "live.js")
    (site / ".nojekyll").write_text("")
    # repo scaffolding
    wf = ROOT / ".github" / "workflows"; wf.mkdir(parents=True, exist_ok=True); (wf / "refresh.yml").write_text(WORKFLOW)
    (ROOT / "README.md").write_text(README); (ROOT / "requirements.txt").write_text(REQS); (ROOT / ".gitignore").write_text(GITIGNORE)
    print("site ->", site, "index", round((site / "index.html").stat().st_size / 1e6, 2), "MB; data",
          round(sum(p.stat().st_size for p in (site / "data").iterdir()) / 1e6, 2), "MB")


def main(argv=None):
    ap = argparse.ArgumentParser(); ap.add_argument("--default-team", default="")
    a = ap.parse_args(argv); build(a.default_team); return 0


if __name__ == "__main__":
    sys.exit(main())
